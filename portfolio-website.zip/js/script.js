function submitForm(e) {
  e.preventDefault();
  alert("Thanks for contacting Mystreyboi!");
}